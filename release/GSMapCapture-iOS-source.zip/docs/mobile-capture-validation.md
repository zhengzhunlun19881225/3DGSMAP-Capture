# 手机采集第一版验证记录

日期：2026-10-11，环境：Windows、项目 `.venv`、Edge，仓库 `S:\Work\3DGSMAP`。

## 已验证

- `test_capture_ingest.py`：2 项通过，覆盖分块重复写入、冲突重试与最终哈希校验。
- `test_mobile_gateway.py` / `test_mobile_recovery.py`：7 项通过，覆盖 Bearer 鉴权、回执续传、一次提交、不可变素材清单、旧 API 任务目录兼容、服务重启、明确拒绝与丢失响应的区分，以及 Windows JavaScript MIME 回归。
- 视频测试使用 FFmpeg 实际生成、带旋转矩阵的 MP4，校验输出方向和来源 PTS；不是仅模拟抽帧函数。
- 上传提交测试转发到隔离的测试 HTTP 服务，校验 multipart 图像及参数，重复请求仅收到一次提交。未用测试素材启动正式 GPU 训练。
- TypeScript 类型检查与 Vite 生产构建通过，生成 `dist/mobile.html`。
- Edge 在 390 × 844、触摸配置下，通过密钥检查接口后仅用 cookie 加载成果页、API 和静态脚本。读取已有完成任务 `1fb12bedce36` 的 PLY（3202 个高斯），等待画布产生图像后检查切换与复位，未出现 JavaScript 运行异常。这个小规模结果用于功能测试，不代表成像质量或目标 iPhone 性能。
- `127.0.0.1:8788` 与电脑自身 Wi-Fi IP `192.168.1.9:8788` 的带密钥健康检查 HTTP 200，现有训练 API 在线。
- Info.plist 能解析，Xcode 工程已包含全部 7 个 Swift 源文件引用。此检查不能代替 Xcode 编译。

既有测试中，Windows 取消子进程测试曾受沙箱限制失败，在沙箱外重跑通过；其余旧测试初次运行通过或按环境跳过。没有把未运行的独立 Nerfstudio 环境检查记作通过。

## 尚需 Mac / iPhone 验证

原生 Swift 编译、开发签名、真机相机权限与旋转、中断保存、APP 重开恢复、Wi-Fi 跨设备连通、手机上传重试、两种模式各一次真实解算训练、WKWebView 在目标 iPhone 上的兼容性与大模型性能。

这些项目的操作步骤与通过条件见 [ios/README.md](../ios/README.md)。当前成果需要连接训练电脑，离线成果下载与后台上传尚未实现。
