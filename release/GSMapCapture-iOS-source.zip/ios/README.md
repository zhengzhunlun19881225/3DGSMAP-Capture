# 3DGSMAP Capture：iPhone 双模式采集

第一版原生源码已接入：离线照片/视频采集 → 同一 Wi-Fi 分块上传 → 电脑准备训练图像 → 原有训练队列 → APP 内查看真实三维成果。

当前验证范围：Windows 接入服务、分块校验/恢复、真实 MP4 抽帧、手机成果网页、前端构建。**尚未在 Mac 上编译、签名或运行 iPhone 真机**。源码包不含 IPA，也不含电脑连接密钥。

## 在 Mac 上直接运行

1. 把 `release/GSMapCapture-iOS-source.zip` 复制到 Mac，解压后保留整个 `ios` 文件夹。
2. 使用 Xcode 打开 `ios/GSMapCapture.xcodeproj`，无需重新创建项目、安装 CocoaPods 或下载 Swift Package。
3. 选择 target **GSMapCapture → Signing & Capabilities**：选择你的 Team，把 Bundle Identifier 从 `com.example.GSMapCapture` 改为自己的唯一标识。
4. 连接 iPhone，选择它作为运行设备。工程最低 iOS 17；关闭手机的竖排方向锁定，允许相机和局域网访问。
5. 点击 Run。真实相机采集请用 iPhone；模拟器只适合检查列表、设置等界面。

工程已包含 Info.plist 权限描述、横竖屏声明和局域网 ATS 配置。视频不录音，不申请麦克风权限。没有开发团队时，工程仍可以先检查源码或尝试模拟器构建。

Mac 上可先做独立编译检查，再进行签名和真机测试：

```bash
xcodebuild -project ios/GSMapCapture.xcodeproj \
  -scheme GSMapCapture -sdk iphonesimulator \
  -configuration Debug CODE_SIGNING_ALLOWED=NO build
```

## 电脑接入服务

训练电脑保持现有 `server/reconstruction_server.py` 服务运行（默认 `127.0.0.1:8787`）。手机接入服务转发给这个服务；计算仍使用其原有队列。

在 Windows PowerShell、仓库目录运行：

```powershell
Set-Location S:\Work\3DGSMAP
.\.venv\Scripts\python.exe -m pip install -r server\requirements-mobile.txt
pnpm build
.\.venv\Scripts\python.exe server\mobile_gateway.py
```

如果接入服务已经监听 8788，无需再启动第二份。接入服务可以独立重启，不要求重启现有训练服务。自定义监听端口用 `MOBILE_PORT`，训练 API 地址用 `MOBILE_TRAINING_API` 环境变量。

首次启动会生成 `runtime/mobile-gateway.json`，其中 `token` 是连接密钥，`server_id` 是电脑身份。保存这个文件才能保持批次与电脑的关联；不要把它放进源码包。使用记事本在本机查看并复制 `token`，APP 将密钥放入系统钥匙串。

本次已检查训练电脑的 Wi-Fi 地址：**`http://192.168.1.9:8788`**。地址可能随路由器分配变化；APP 应填写电脑的局域网地址，不能填写 `localhost`。手机连接同一 Wi-Fi，如 Windows 弹出防火墙提示，允许这个 Python 服务在专用网络访问。尚未验证从你的 iPhone 穿过防火墙的访问。

## 操作路径

1. **我的项目 → 新项目 → 照片采集 / 视频采集**。
2. 照片支持手动、2 秒间隔和上一张半透明参考；视频要求横屏，提供上层、中层、下层、细节四阶段，可调绿线、房间示意、转动速度提示与录制计时。
3. 原件保存在手机 Application Support；项目、阶段、跳过记录、尺寸/编码、视频时长和任务关联写入持久 JSON 索引。辅助层不会写进原始照片或视频。
4. 回到同一 Wi-Fi，**连接电脑**，输入地址和密钥，点“检查连接并保存”。
5. 点项目里的采集批次，检查原件，选择方案/档位，点“上传此批次并训练”。每个批次独立提交，第一版不合并不同批次训练。提交后该批次固定，补拍使用新批次。
6. **上传时保持 APP 在前台**。照片/视频按 4 MiB 分块，电脑校验长度和 SHA-256。断线、取消或关闭 APP 后，重新点上传，查询电脑回执并续传。电脑收到任务编号后，手机可离开 Wi-Fi，训练继续。
7. 回到 Wi-Fi 打开批次 → 查看训练进度与成果 → 打开三维成果。通过 WKWebView 加载同源成果页，支持旋转、缩放、GS/点云切换和复位。

电脑端照片做方向规范化，视频按用户选择的时间间隔抽取实际源帧，保留真实 PTS 与来源哈希。默认每 0.5 秒取一帧，总输入最多 2000 张；超过上限需增加间隔或分批。训练仍需要足够的视角重叠和清晰纹理，能抽帧不等于能够成功解算。

## 真机验收

逐项记录实际结果，不能用界面出现按钮代替验收：

| 检查 | 通过条件 |
| --- | --- |
| 离线照片 | 飞行模式拍摄，重启 APP 后原图与批次仍可打开；原图没有绿线/参考图 |
| 离线视频 | 横屏两方向各录一个片段，预览方向正确、时长正确；停止后才能切换阶段 |
| 中断与退出 | 录制中退出/切后台/来电，成功写入片段可打开，失败片段显示错误；不承诺后台录像 |
| 阶段与项目 | 两种模式归属同一项目，跳过记录与文件对应；未结束且未上传的批次可以继续 |
| 连接 | APP 输入地址和密钥后显示训练 API 在线；错误密钥被拒绝 |
| 断线续传 | 较大视频上传中断网，再连接后只发送缺失块；重开 APP 后仍可恢复 |
| 单次提交 | 同一批次重复点击、重复请求只恢复同一个任务编号 |
| 服务重启 | 上传中的回执保留；预处理重启后显式重试；提交结果不确定时先在电脑确认任务，避免重复计算 |
| 照片端到端 | 用真实重叠照片完成一次解算与训练，APP 可读取任务并打开成果 |
| 视频端到端 | 用真实移动机位视频完成一次抽帧、解算与训练，APP 可打开成果 |

首版成果查看需要连接训练电脑；尚未实现下载后离线查看、手机专用轻量成果、自动墙面识别、覆盖率、图像质量评分、后台上传或素材删除管理。较大的原始 PLY 需要在目标 iPhone 验证内存和帧率。

## 源码分工

- `GSMapCapture/`：原生 SwiftUI、AVFoundation、Core Motion、持久项目索引、上传及 WKWebView。
- `GSMapCapture.xcodeproj/`：可直接打开的工程；`generate_xcode_project.py` 用于重新生成基础工程，已有签名设置后不要直接覆盖。
- `../server/mobile_gateway.py`、`capture_ingest.py`：电脑接入、校验、抽帧、转发训练与状态代理。
- `../mobile.html`、`../src/mobile.tsx`：手机成果网页，复用现有真实高斯渲染器。

局域网权限与 ATS 依据：[Apple 局域网权限说明](https://developer.apple.com/documentation/technotes/tn3179-understanding-local-network-privacy)、[Apple NSAllowsLocalNetworking](https://developer.apple.com/documentation/bundleresources/information-property-list/nsapptransportsecurity/nsallowslocalnetworking)。
