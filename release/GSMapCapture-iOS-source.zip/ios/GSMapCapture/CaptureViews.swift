import SwiftUI
import UIKit

struct ProjectListView: View {
    @EnvironmentObject private var store: CaptureStore
    @State private var showingNewProject = false
    @State private var newName = ""
    @State private var showingConnection = false

    var body: some View {
        NavigationStack {
            List {
                if store.projects.isEmpty {
                    ContentUnavailableView("还没有项目", systemImage: "cube.transparent", description: Text("创建项目后开始照片或视频采集"))
                }
                if let error = store.errorMessage { Text(error).foregroundStyle(.red).font(.footnote) }
                ForEach(store.projects) { project in
                    NavigationLink {
                        ProjectDetailView(project: project)
                    } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            Text(project.name).font(.headline)
                            Text("\(store.mediaCount(project: project)) 个素材 · \(project.sessions.count) 个采集批次")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("我的项目")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button { showingConnection = true } label: { Label("连接电脑", systemImage: "desktopcomputer") } }
                Button { showingNewProject = true } label: { Label("新项目", systemImage: "plus") }.disabled(!store.canCapture)
            }
            .sheet(isPresented: $showingConnection) { ConnectionSettingsView() }
            .sheet(isPresented: $showingNewProject) {
                NavigationStack {
                    Form { TextField("项目名称", text: $newName) }
                        .navigationTitle("新建项目")
                        .toolbar {
                            ToolbarItem(placement: .cancellationAction) { Button("取消") { showingNewProject = false } }
                            ToolbarItem(placement: .confirmationAction) {
                                Button("创建") { _ = store.createProject(name: newName); newName = ""; showingNewProject = false }
                            }
                        }
                }
                .presentationDetents([.medium])
            }
        }
    }
}

struct ProjectDetailView: View {
    @EnvironmentObject private var store: CaptureStore
    let project: CaptureProject
    @State private var captureRoute: CaptureRoute?

    private var current: CaptureProject { store.projects.first(where: { $0.id == project.id }) ?? project }

    var body: some View {
        List {
            Section("开始采集") {
                Button { begin(.photo) } label: { Label("照片采集", systemImage: "camera") }
                Button { begin(.video) } label: { Label("视频采集", systemImage: "video") }
            }.disabled(!store.canCapture)
            Section("项目记录") {
                if current.sessions.isEmpty { Text("照片、视频和阶段记录会归到同一项目").foregroundStyle(.secondary) }
                ForEach(current.sessions) { session in
                    NavigationLink {
                        CaptureSessionDetailView(projectId: current.id, sessionId: session.id)
                    } label: {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("\(session.mode.title) · \(session.createdAt.formatted(date: .abbreviated, time: .shortened))")
                            Text("\(session.media.count) 个素材 · 跳过 \(session.skippedStages.count) 个阶段")
                                .font(.caption).foregroundStyle(.secondary)
                            if let job = session.jobId { Text("任务 \(job)").font(.caption).foregroundStyle(.green) }
                        }
                    }
                    if session.endedAt == nil && session.serverId == nil {
                        Button("继续未完成的\(session.mode.title)") {
                            store.restoreSession(session.id)
                            captureRoute = CaptureRoute(id: session.id, mode: session.mode)
                        }
                    }
                }
            }
            Section("下一步") {
                Label("回到训练电脑所在 Wi-Fi 后上传", systemImage: "wifi")
                    .font(.footnote).foregroundStyle(.secondary)
                Text("点击采集批次，检查素材并上传训练").font(.footnote)
            }
        }
        .navigationTitle(current.name)
        .fullScreenCover(item: $captureRoute) { route in
            CaptureView(projectId: current.id, sessionId: route.id, mode: route.mode)
                .environmentObject(store)
        }
    }

    private func begin(_ mode: CaptureMode) {
        let sessionId = store.startSession(projectId: current.id, mode: mode)
        captureRoute = CaptureRoute(id: sessionId, mode: mode)
    }
}

struct CaptureView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var store: CaptureStore
    @StateObject private var camera = CameraService()
    @StateObject private var motion = MotionService()
    let projectId: UUID
    let sessionId: UUID
    let mode: CaptureMode
    @State private var stage: CaptureStage = .upper
    @State private var showGuide = true
    @State private var linePosition: Double = CaptureStage.upper.linePosition
    @State private var showGhost = false
    @State private var lastPhoto: UIImage?
    @State private var intervalEnabled = false
    @State private var intervalRunning = false
    @State private var intervalTimer: Timer?
    @State private var finishing = false
    @State private var landscape = false
    @State private var permissionAlert = false
    @State private var feedback = "参考线只用于屏幕预览，不会写入素材"

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            CameraPreview(session: camera.session).ignoresSafeArea()
            ReferenceOverlay(stage: stage, linePosition: linePosition, showGhost: showGhost, lastPhoto: lastPhoto)
            VStack(spacing: 0) {
                HStack {
                    Button { finish() } label: { Image(systemName: "xmark").font(.headline).padding(12).background(.black.opacity(0.45), in: Circle()) }
                    Spacer()
                    if let started = camera.recordingStartedAt {
                        TimelineView(.periodic(from: started, by: 1)) { timeline in
                            let elapsed = max(0, Int(timeline.date.timeIntervalSince(started)))
                            Text(String(format: "%02d:%02d", elapsed / 60, elapsed % 60)).font(.caption.monospacedDigit()).foregroundStyle(.red)
                        }
                    }
                    Label(mode == .video ? "视频采集 · \(stage.title)" : "照片采集", systemImage: mode == .video ? "video" : "camera")
                        .font(.subheadline.weight(.medium)).padding(.horizontal, 12).padding(.vertical, 8)
                        .background(.black.opacity(0.5), in: Capsule())
                }.padding()
                Spacer()
                if mode == .video { stagePicker }
                VStack(spacing: 12) {
                    if mode == .photo {
                        HStack {
                            Toggle("2 秒间隔", isOn: $intervalEnabled).disabled(intervalRunning).frame(maxWidth: 160)
                            Toggle("上一张参考", isOn: $showGhost).frame(maxWidth: 180)
                        }.font(.caption).padding(.horizontal)
                    } else if stage != .detail {
                        HStack { Text("参考线").font(.caption); Slider(value: $linePosition, in: 0.18...0.82); Text("手动对齐").font(.caption2) }.padding(.horizontal)
                    }
                    Text(feedback).font(.footnote).padding(.horizontal, 14).padding(.vertical, 8)
                        .background(.black.opacity(0.58), in: Capsule())
                    HStack(alignment: .center) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text(motion.guidance).font(.caption).foregroundStyle(.green)
                            Text("姿态反馈仅作辅助，请手动确认参考线").font(.caption2).foregroundStyle(.white.opacity(0.75))
                        }.frame(maxWidth: .infinity, alignment: .leading)
                        Button { shutter() } label: {
                            Circle().fill(camera.isRecording ? .red : (mode == .photo ? .white : .red))
                                .frame(width: 66, height: 66).overlay(Circle().stroke(.white, lineWidth: 3))
                                .overlay { if camera.isRecording || intervalRunning { RoundedRectangle(cornerRadius: 5).fill(.white).frame(width: 22, height: 22) } }
                        }.accessibilityLabel(camera.isRecording ? "停止录制" : (mode == .photo ? "拍摄照片" : "开始录制"))
                            .disabled(!camera.isConfigured || finishing || (mode == .video && (!landscape || (camera.isBusy && !camera.isRecording))) || (mode == .photo && camera.isBusy))
                        Button { advance() } label: { Text(stage == .detail ? "完成" : "下一步").font(.footnote).padding(.horizontal, 14).padding(.vertical, 12).background(.black.opacity(0.52), in: RoundedRectangle(cornerRadius: 10)) }
                            .disabled(camera.isBusy || intervalRunning)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                    }.padding(.horizontal)
                }.padding(.bottom, 18)
            }
            if mode == .video && !landscape {
                Color.black.opacity(0.85).ignoresSafeArea().overlay {
                    VStack(spacing: 18) { Image(systemName: "iphone.gen3.radiowaves.left.and.right").font(.largeTitle); Text("请将手机横置"); Button("退出") { finish() }.buttonStyle(.bordered) }
                }
            } else if showGuide { GuideCard(stage: stage, mode: mode, onContinue: { showGuide = false }, onSkip: skipStage) }
        }
        .statusBarHidden(true)
        .onAppear {
            camera.onPhotoSaved = { url in
                lastPhoto = UIImage(contentsOfFile: url.path)
                let saved = store.addMedia(sessionId: sessionId, url: url, mode: .photo, stage: stage, duration: nil)
                feedback = saved ? "照片已保存到项目" : (store.errorMessage ?? "记录写入失败")
                if finishing { closeSession() }
            }
            camera.onVideoSaved = { url, duration, width, height, codec in
                let saved = store.addMedia(sessionId: sessionId, url: url, mode: .video, stage: stage, duration: duration, width: width, height: height, codec: codec)
                feedback = saved ? "视频片段已保存到项目" : (store.errorMessage ?? "记录写入失败")
                if finishing { closeSession() }
            }
            if let record = store.projects.first(where: { $0.id == projectId })?.sessions.first(where: { $0.id == sessionId }), let last = record.media.last {
                stage = last.stage; linePosition = stage.linePosition
                if last.mode == .photo { lastPhoto = UIImage(contentsOfFile: store.fileURL(last).path) }
            }
            UIDevice.current.beginGeneratingDeviceOrientationNotifications()
            camera.requestAndConfigure(); motion.start(); updateRotation()
        }
        .onDisappear { stopInterval(); camera.pauseSession(); motion.stop(); UIDevice.current.endGeneratingDeviceOrientationNotifications() }
        .onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in updateRotation() }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active { stopInterval(); camera.pauseSession(); motion.stop(); feedback = "采集已中断，请检查当前片段" }
            else { camera.requestAndConfigure(); motion.start(); updateRotation() }
        }
        .onChange(of: camera.errorMessage) { _, error in
            if let error { feedback = error; stopInterval(); finishing = false }
        }
        .onChange(of: camera.isBusy) { _, busy in if !busy { updateRotation() } }
        .onChange(of: camera.isRecording) { _, recording in
            feedback = recording ? "录制中，缓慢移动机位" : "正在校验并保存片段"
        }
        .onChange(of: camera.permissionDenied) { _, denied in permissionAlert = denied }
        .alert("相机不可用", isPresented: $permissionAlert) {
            Button("打开设置") { if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) } }
            Button("退出采集", role: .cancel) { finish() }
        } message: { Text("请在系统设置中允许相机权限") }
    }

    private var stagePicker: some View {
        HStack(spacing: 7) {
            ForEach(CaptureStage.allCases) { value in
                Button(value.title) { stage = value; linePosition = value.linePosition; showGuide = true }
                    .disabled(camera.isBusy)
                    .font(.caption).frame(maxWidth: .infinity).padding(.vertical, 9)
                    .background(value == stage ? .green.opacity(0.25) : .black.opacity(0.45), in: RoundedRectangle(cornerRadius: 8))
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(value == stage ? .green : .clear, lineWidth: 1))
            }
        }.padding(.horizontal)
    }

    private func shutter() {
        if mode == .photo {
            if intervalRunning { stopInterval(); return }
            camera.capturePhoto()
            if intervalEnabled {
                intervalRunning = true
                intervalTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { _ in
                    if !camera.isBusy { camera.capturePhoto() }
                }
            }
            return
        }
        camera.toggleVideo()
        feedback = camera.isRecording ? "正在停止录制" : "正在开始录制"
    }

    private func advance() {
        guard mode == .video else { finish(); return }
        guard stage != .detail else { finish(); return }
        stage = CaptureStage.allCases[CaptureStage.allCases.firstIndex(of: stage)! + 1]
        linePosition = stage.linePosition; showGuide = true
    }

    private func skipStage() { store.skip(stage: stage, sessionId: sessionId); advance() }
    private func stopInterval() { intervalTimer?.invalidate(); intervalTimer = nil; intervalRunning = false }
    private func finish() {
        stopInterval()
        if camera.isBusy { finishing = true; camera.stop(); feedback = "正在保存当前素材，请稍候" }
        else { closeSession() }
    }
    private func closeSession() { store.finishSession(sessionId: sessionId); dismiss() }
    private func updateRotation() {
        guard !camera.isBusy else { return }
        let orientation = (UIApplication.shared.connectedScenes.first as? UIWindowScene)?.interfaceOrientation ?? .portrait
        landscape = orientation.isLandscape
        let angle: CGFloat = orientation == .landscapeLeft ? 0 : orientation == .landscapeRight ? 180 : orientation == .portraitUpsideDown ? 270 : 90
        camera.setRotation(angle)
    }
}

struct ReferenceOverlay: View {
    let stage: CaptureStage
    let linePosition: Double
    let showGhost: Bool
    let lastPhoto: UIImage?
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                if showGhost, let lastPhoto { Image(uiImage: lastPhoto).resizable().scaledToFill().frame(width: proxy.size.width, height: proxy.size.height).clipped().opacity(0.20) }
                Rectangle().stroke(.green, style: StrokeStyle(lineWidth: 2, dash: [8, 7])).frame(height: 2).position(x: proxy.size.width / 2, y: proxy.size.height * linePosition)
                VStack { Spacer(); Text(stage.instruction).font(.caption).padding(.horizontal, 12).padding(.vertical, 8).background(.black.opacity(0.48), in: Capsule()).padding(.bottom, 145) }
            }
        }.allowsHitTesting(false)
    }
}

struct GuideCard: View {
    let stage: CaptureStage
    let mode: CaptureMode
    let onContinue: () -> Void
    let onSkip: () -> Void
    var body: some View {
        Color.black.opacity(0.74).ignoresSafeArea().overlay {
            VStack(spacing: 18) {
                if mode == .video { RoomGuideIllustration(stage: stage).frame(width: 210, height: 110) }
                else { Image(systemName: "camera.viewfinder").font(.system(size: 44)) }
                Text(mode == .video ? "第\(CaptureStage.allCases.firstIndex(of: stage)! + 1) 步：\(stage.title)" : "照片采集准备").font(.title3.weight(.semibold))
                Text(mode == .video ? "站在房间边缘，背靠墙面。第\(CaptureStage.allCases.firstIndex(of: stage)! + 1) 步：\(stage.instruction)" : "移动机位，保持相邻照片有重叠。拍摄后原图保存在手机。")
                    .font(.subheadline).multilineTextAlignment(.center).foregroundStyle(.secondary).frame(maxWidth: 330)
                HStack {
                    if mode == .video { Button("跳过本阶段", action: onSkip).buttonStyle(.bordered) }
                    Button("进入拍摄", action: onContinue).buttonStyle(.borderedProminent)
                }
            }.padding(28).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22)).padding(24)
        }
    }
}

struct RoomGuideIllustration: View {
    let stage: CaptureStage
    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width
            let height = geometry.size.height
            let inset: CGFloat = 20
            ZStack {
                Path { path in
                    path.addRect(CGRect(x: 2, y: 2, width: width - 4, height: height - 4))
                    path.addRect(CGRect(x: inset, y: inset, width: width - inset * 2, height: height - inset * 2))
                    for point in [CGPoint(x: 2, y: 2), CGPoint(x: width - 2, y: 2), CGPoint(x: 2, y: height - 2), CGPoint(x: width - 2, y: height - 2)] {
                        path.move(to: point)
                        path.addLine(to: CGPoint(x: point.x < width / 2 ? inset : width - inset, y: point.y < height / 2 ? inset : height - inset))
                    }
                }.stroke(.white.opacity(0.65), lineWidth: 1)
                if stage == .detail {
                    Image(systemName: "arrow.triangle.2.circlepath").font(.system(size: 32)).foregroundStyle(.green)
                } else {
                    Path { path in
                        let y = stage == .upper ? inset : stage == .lower ? height - inset : height / 2
                        path.move(to: CGPoint(x: inset, y: y))
                        path.addLine(to: CGPoint(x: width - inset, y: y))
                    }.stroke(.green, style: StrokeStyle(lineWidth: 3, dash: [6, 5]))
                }
            }
        }.accessibilityLabel("房间拍摄参考示意：\(stage.title)")
    }
}
