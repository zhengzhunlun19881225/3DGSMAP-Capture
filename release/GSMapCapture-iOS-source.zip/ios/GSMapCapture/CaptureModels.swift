import Foundation

enum CaptureMode: String, Codable, CaseIterable, Identifiable {
    case photo, video
    var id: String { rawValue }
    var title: String { self == .photo ? "照片采集" : "视频采集" }
}

enum CaptureStage: String, Codable, CaseIterable, Identifiable {
    case upper, middle, lower, detail
    var id: String { rawValue }
    var title: String {
        switch self { case .upper: "上层"; case .middle: "中层"; case .lower: "下层"; case .detail: "细节" }
    }
    var instruction: String {
        switch self {
        case .upper: "对齐墙面与天花板交界，沿房间缓慢移动"
        case .middle: "保持相邻画面重叠，记录墙面与主要物体"
        case .lower: "对齐墙面与地板交界，补拍低处"
        case .detail: "环绕重要物体，从不同位置补拍细节"
        }
    }
    var linePosition: Double {
        switch self { case .upper: 0.30; case .middle: 0.49; case .lower: 0.72; case .detail: 0.49 }
    }
}

struct MediaRecord: Codable, Identifiable {
    let id: UUID
    let mode: CaptureMode
    let relativePath: String
    let createdAt: Date
    let stage: CaptureStage
    let duration: Double?
    let byteCount: Int64?
    var pixelWidth: Int?
    var pixelHeight: Int?
    var codec: String?
    var orientation: Int?
}

struct CaptureSessionRecord: Codable, Identifiable {
    let id: UUID
    let projectId: UUID
    let mode: CaptureMode
    let createdAt: Date
    var endedAt: Date?
    var media: [MediaRecord]
    var skippedStages: [CaptureStage]
    var serverId: String?
    var jobId: String?
}

struct CaptureRoute: Identifiable {
    let id: UUID
    let mode: CaptureMode
}

struct CaptureProject: Codable, Identifiable {
    let id: UUID
    var name: String
    let createdAt: Date
    var updatedAt: Date
    var sessions: [CaptureSessionRecord]
}
