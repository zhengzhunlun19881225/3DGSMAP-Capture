import SwiftUI

@main
struct GSMapCaptureApp: App {
    @StateObject private var store = CaptureStore()
    @StateObject private var connection = MobileConnection()

    var body: some Scene {
        WindowGroup {
            ProjectListView()
                .environmentObject(store)
                .environmentObject(connection)
                .preferredColorScheme(.dark)
        }
    }
}
