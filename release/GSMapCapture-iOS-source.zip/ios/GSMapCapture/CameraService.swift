import AVFoundation
import CoreMotion
import Foundation
import SwiftUI
import Combine
import UIKit

final class CameraService: NSObject, ObservableObject {
    let session = AVCaptureSession()
    private let queue = DispatchQueue(label: "com.3dgsmap.camera")
    private let photoOutput = AVCapturePhotoOutput()
    private let movieOutput = AVCaptureMovieFileOutput()
    private var currentVideoURL: URL?
    private var currentVideoStarted: Date?
    private var configured = false
    private var pendingPhoto = false
    private var movieRequested = false
    private var stopRequested = false
    private var rotation: CGFloat = 90

    @Published private(set) var permissionDenied = false
    @Published private(set) var isConfigured = false
    @Published private(set) var isRecording = false
    @Published private(set) var isBusy = false
    @Published private(set) var recordingStartedAt: Date?
    @Published var errorMessage: String?
    var onPhotoSaved: ((URL) -> Void)?
    var onVideoSaved: ((URL, TimeInterval, Int, Int, String) -> Void)?

    func requestAndConfigure() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            DispatchQueue.main.async { self.permissionDenied = false }
            configure()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] allowed in
                DispatchQueue.main.async { self?.permissionDenied = !allowed }
                if allowed { self?.configure() }
            }
        default: DispatchQueue.main.async { self.permissionDenied = true }
        }
    }

    private func configure() {
        queue.async { [weak self] in
            guard let self else { return }
            if self.configured { if !self.session.isRunning { self.session.startRunning() }; return }
            self.session.beginConfiguration()
            self.session.sessionPreset = self.session.canSetSessionPreset(.hd1920x1080) ? .hd1920x1080 : .high
            guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
                  let input = try? AVCaptureDeviceInput(device: device), self.session.canAddInput(input) else {
                self.finishConfiguration(error: "无法打开后置摄像头"); return
            }
            self.session.addInput(input)
            if device.activeFormat.videoSupportedFrameRateRanges.contains(where: { $0.minFrameRate <= 30 && $0.maxFrameRate >= 30 }) {
                do {
                    try device.lockForConfiguration()
                    device.activeVideoMinFrameDuration = CMTime(value: 1, timescale: 30)
                    device.activeVideoMaxFrameDuration = CMTime(value: 1, timescale: 30)
                    if device.isVideoHDREnabled { device.automaticallyAdjustsVideoHDREnabled = false; device.isVideoHDREnabled = false }
                    device.unlockForConfiguration()
                } catch { DispatchQueue.main.async { self.errorMessage = "帧率设置未生效：\(error.localizedDescription)" } }
            }
            guard self.session.canAddOutput(self.photoOutput), self.session.canAddOutput(self.movieOutput) else {
                self.finishConfiguration(error: "无法配置照片和视频输出"); return
            }
            self.session.addOutput(self.photoOutput)
            self.session.addOutput(self.movieOutput)
            self.session.commitConfiguration()
            self.configured = true
            self.setLandscapeConnections()
            self.session.startRunning()
            DispatchQueue.main.async { self.isConfigured = true }
        }
    }

    private func finishConfiguration(error: String) {
        session.commitConfiguration()
        DispatchQueue.main.async { self.errorMessage = error }
    }

    private func setLandscapeConnections() {
        for output in [photoOutput as AVCaptureOutput, movieOutput as AVCaptureOutput] {
            guard let connection = output.connection(with: .video) else { continue }
            if #available(iOS 17.0, *), connection.isVideoRotationAngleSupported(rotation) { connection.videoRotationAngle = rotation }
            else if connection.isVideoOrientationSupported { connection.videoOrientation = .landscapeRight }
        }
    }

    func capturePhoto() {
        queue.async { [weak self] in
            guard let self, self.configured, !self.movieRequested, !self.pendingPhoto else { return }
            self.pendingPhoto = true
            DispatchQueue.main.async { self.isBusy = true }
            self.setLandscapeConnections()
            self.photoOutput.capturePhoto(with: AVCapturePhotoSettings(format: [AVVideoCodecKey: AVVideoCodecType.jpeg]), delegate: self)
        }
    }

    func toggleVideo() {
        queue.async { [weak self] in
            guard let self, self.configured, !self.pendingPhoto else { return }
            if self.movieRequested {
                self.stopRequested = true
                if self.movieOutput.isRecording { self.movieOutput.stopRecording() }
                return
            }
            self.movieRequested = true; self.stopRequested = false
            let directory = FileManager.default.temporaryDirectory
            let url = directory.appendingPathComponent("capture-\(UUID().uuidString).mov")
            self.currentVideoURL = url
            self.currentVideoStarted = Date()
            self.setLandscapeConnections()
            self.movieOutput.startRecording(to: url, recordingDelegate: self)
            DispatchQueue.main.async { self.isBusy = true }
        }
    }

    func stop() {
        queue.async { [weak self] in
            guard let self else { return }
            self.stopRequested = true
            if self.movieOutput.isRecording { self.movieOutput.stopRecording() }
        }
    }

    func pauseSession() {
        queue.async { [weak self] in
            guard let self else { return }
            self.stopRequested = true
            if self.movieOutput.isRecording { self.movieOutput.stopRecording() }
            if self.session.isRunning { self.session.stopRunning() }
        }
    }

    func setRotation(_ angle: CGFloat) { queue.async { self.rotation = angle } }

    private func savedURL(fileExtension: String) -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent("capture-\(UUID().uuidString).\(fileExtension)")
    }

    func previewView() -> CameraPreview { CameraPreview(session: session) }

    deinit { if session.isRunning { session.stopRunning() } }
}

extension CameraService: AVCapturePhotoCaptureDelegate {
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        queue.async { self.pendingPhoto = false }
        DispatchQueue.main.async { self.isBusy = false }
        guard error == nil, let data = photo.fileDataRepresentation() else {
            DispatchQueue.main.async { self.errorMessage = error?.localizedDescription ?? "照片保存失败" }; return
        }
        let url = savedURL(fileExtension: "jpg")
        do { try data.write(to: url); DispatchQueue.main.async { self.onPhotoSaved?(url) } }
        catch { DispatchQueue.main.async { self.errorMessage = "照片写入失败：\(error.localizedDescription)" } }
    }
}

extension CameraService: AVCaptureFileOutputRecordingDelegate {
    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        DispatchQueue.main.async { self.isRecording = true; self.recordingStartedAt = Date() }
        queue.async { if self.stopRequested { self.movieOutput.stopRecording() } }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        DispatchQueue.main.async { self.isRecording = false; self.recordingStartedAt = nil }
        let destination = savedURL(fileExtension: "mov")
        do {
            if let error, ((error as NSError).userInfo[AVErrorRecordingSuccessfullyFinishedKey] as? Bool) != true {
                throw error
            }
            try FileManager.default.moveItem(at: outputFileURL, to: destination)
            Task {
                do {
                    let asset = AVURLAsset(url: destination)
                    let duration = try await asset.load(.duration).seconds
                    let tracks = try await asset.loadTracks(withMediaType: .video)
                    guard let track = tracks.first, duration.isFinite, duration > 0 else { throw NSError(domain: "Capture", code: 1, userInfo: [NSLocalizedDescriptionKey: "视频没有有效画面或时长"]) }
                    let size = try await track.load(.naturalSize)
                    let transform = try await track.load(.preferredTransform)
                    let bounds = CGRect(origin: .zero, size: size).applying(transform)
                    let descriptions = try await track.load(.formatDescriptions)
                    let subtype = descriptions.first.map { CMFormatDescriptionGetMediaSubType($0) } ?? 0
                    let codec = String(bytes: [UInt8((subtype >> 24) & 255), UInt8((subtype >> 16) & 255), UInt8((subtype >> 8) & 255), UInt8(subtype & 255)], encoding: .ascii) ?? "unknown"
                    self.queue.async { self.movieRequested = false }
                    DispatchQueue.main.async { self.isBusy = false; self.onVideoSaved?(destination, duration, Int(abs(bounds.width)), Int(abs(bounds.height)), codec) }
                } catch {
                    self.queue.async { self.movieRequested = false }
                    DispatchQueue.main.async { self.isBusy = false; self.errorMessage = "视频校验失败：\(error.localizedDescription)" }
                }
            }
        } catch {
            queue.async { self.movieRequested = false }
            DispatchQueue.main.async { self.isBusy = false; self.errorMessage = "视频保存失败：\(error.localizedDescription)" }
        }
        currentVideoURL = nil; currentVideoStarted = nil
    }
}

struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession
    func makeUIView(context: Context) -> PreviewView { let view = PreviewView(); view.previewLayer.session = session; return view }
    func updateUIView(_ uiView: PreviewView, context: Context) { uiView.previewLayer.session = session }
}

final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var previewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
    override init(frame: CGRect) { super.init(frame: frame); previewLayer.videoGravity = .resizeAspectFill }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    override func layoutSubviews() {
        super.layoutSubviews()
        guard let connection = previewLayer.connection else { return }
        let angle: CGFloat
        switch window?.windowScene?.interfaceOrientation {
        case .landscapeLeft: angle = 0
        case .landscapeRight: angle = 180
        case .portraitUpsideDown: angle = 270
        default: angle = 90
        }
        if connection.isVideoRotationAngleSupported(angle) { connection.videoRotationAngle = angle }
    }
}

final class MotionService: ObservableObject {
    private let manager = CMMotionManager()
    @Published private(set) var pitch: Double = 0
    @Published private(set) var roll: Double = 0
    @Published private(set) var guidance = "参考线由用户手动对齐"

    func start() {
        guard manager.isDeviceMotionAvailable else { return }
        manager.deviceMotionUpdateInterval = 1.0 / 20.0
        manager.startDeviceMotionUpdates(to: .main) { [weak self] motion, _ in
            guard let motion, let self else { return }
            self.pitch = motion.attitude.pitch * 180 / .pi
            self.roll = motion.attitude.roll * 180 / .pi
            let angularSpeed = sqrt(pow(motion.rotationRate.x, 2) + pow(motion.rotationRate.y, 2) + pow(motion.rotationRate.z, 2))
            self.guidance = angularSpeed > 0.8 ? "转动较快，请放慢" : "转动较缓，请保持画面重叠"
        }
    }
    func stop() { manager.stopDeviceMotionUpdates() }
}
